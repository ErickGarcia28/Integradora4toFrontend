package utez.edu.mx.models

data class User(
    val name: String,
    val email: String
)
