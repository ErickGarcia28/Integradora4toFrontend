package utez.edu.mx.models

data class Task (
    val task_id: String = "",
    val title: String = "",
    val description: String = ""
)